﻿namespace _102_4
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.openBmpBtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.DilationBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // openBmpBtn
            // 
            this.openBmpBtn.Location = new System.Drawing.Point(13, 484);
            this.openBmpBtn.Name = "openBmpBtn";
            this.openBmpBtn.Size = new System.Drawing.Size(128, 63);
            this.openBmpBtn.TabIndex = 0;
            this.openBmpBtn.Text = "開啟圖檔";
            this.openBmpBtn.UseVisualStyleBackColor = true;
            this.openBmpBtn.Click += new System.EventHandler(this.openBmpBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(13, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(484, 441);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // DilationBtn
            // 
            this.DilationBtn.Location = new System.Drawing.Point(369, 484);
            this.DilationBtn.Name = "DilationBtn";
            this.DilationBtn.Size = new System.Drawing.Size(128, 63);
            this.DilationBtn.TabIndex = 0;
            this.DilationBtn.Text = "膨脹處理";
            this.DilationBtn.UseVisualStyleBackColor = true;
            this.DilationBtn.Click += new System.EventHandler(this.DilationBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(532, 572);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.DilationBtn);
            this.Controls.Add(this.openBmpBtn);
            this.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "102 年度工科技藝競賽第四題 膨脹處理程式";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button openBmpBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button DilationBtn;
    }
}

