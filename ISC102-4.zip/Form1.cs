﻿/// 教育部工科技藝競賽 102 年第四題 膨脹處理程式
/// 漆家豪 於 海青工商 2024/3/3
using System;
using System.Drawing;
using System.Windows.Forms;

namespace _102_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void openBmpBtn_Click(object sender, EventArgs e)
        {
            //打開檔案對話框，設定初始路徑為專案文件所在位置
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "BMP Files|*.bmp";
            openFileDialog1.Title = "選擇 BMP 檔案";
            openFileDialog1.InitialDirectory = Application.StartupPath;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    //開啟選擇的 BMP 檔案
                    string filePath = openFileDialog1.FileName;
                    Bitmap originalBmp = new Bitmap(filePath);
                    

                    // 放大圖片
                    Bitmap resizedBmp = new Bitmap(originalBmp.Width, originalBmp.Height);
                    using (Graphics g = Graphics.FromImage(resizedBmp))
                    {
                        g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                        g.DrawImage(originalBmp, 0, 0, originalBmp.Width, originalBmp.Height);
                    }

                    // 顯示放大後的 BMP 圖片到 PictureBox 控制項上
                    pictureBox1.Image = resizedBmp;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("無法開啟檔案: " + ex.Message);
                }
            }
        }

        private void DilationBtn_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("請先選擇一張圖像");
                return;
            }
            Bitmap originalBmp = new Bitmap(pictureBox1.Image);//取得圖片

            //創建一個新的 Bitmap 對象，用於存放處理後的圖片
            Bitmap processedBmp = new Bitmap(originalBmp.Width, originalBmp.Height);

            //對每個像素進行 Dilation 處理
            for (int y = 0; y < originalBmp.Height; y++)
            {
                for (int x = 0; x < originalBmp.Width; x++)
                {
                    Color pixel = originalBmp.GetPixel(x, y);

                    // 如果像素為黑色，則將其周圍的 8 個像素都設為黑色
                    if (pixel.ToArgb() == Color.Black.ToArgb())
                    {
                        for (int dy = -1; dy <= 1; dy++)
                        {
                            for (int dx = -1; dx <= 1; dx++)
                            {
                                int newX = x + dx;
                                int newY = y + dy;

                                // 確保新座標在圖片範圍內
                                if (newX >= 0 && newX < originalBmp.Width && newY >= 0 && newY < originalBmp.Height)
                                {
                                    processedBmp.SetPixel(newX, newY, Color.Black);
                                }
                            }
                        }
                    }
                }
            }
            // 將處理後的圖片顯示在 PictureBox 控制項上
            pictureBox1.Image = processedBmp;
        }
    }
}
